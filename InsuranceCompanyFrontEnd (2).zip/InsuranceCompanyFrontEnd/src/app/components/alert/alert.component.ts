import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/services/alert/alert.service';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css'],
})
export class AlertComponent implements OnInit {

  toShowAlert: boolean = false;
  type: string = "danger";
  message: string = "No issues";

  constructor(private alertService: AlertService) { }

  ngOnInit(): void {
    this.alertService.showAlert.subscribe(
      (data: { alert: boolean, type: string, message: string }) => {

        this.toShowAlert = data['alert'];
        this.type = data['type']
        this.message = data['message']
        setTimeout(() => {
          this.toShowAlert = false
        }, 3000);
      }

    )
  }

}
