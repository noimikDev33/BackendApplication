import { Component, OnInit } from '@angular/core';
import { faLock } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { User } from './model';
import { FormControl, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/services/auth/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  faLock = faLock
  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl('')

  })
  constructor(private auth: AuthService, private router: Router) { }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.auth.login(this.loginForm.value).subscribe(
        (result) => {
          if (result.email == "noimik@gmail.com") {
            console.log("true");
            this.router.navigate(['/admin/about']);
          }
          else if (result.email == "policy@gmail.com") {
            this.router.navigate(['/policy/view'])
          }
        },
        (err: Error) => {
          alert(err.message);
        }
      );
    }
  }



  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['admin/about']);
    }
  }

}
