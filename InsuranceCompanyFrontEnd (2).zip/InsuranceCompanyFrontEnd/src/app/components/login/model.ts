export interface User{
    email:any;
    password:any;
}