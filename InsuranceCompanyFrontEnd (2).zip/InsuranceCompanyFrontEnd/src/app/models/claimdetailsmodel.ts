export class ClaimDetails {

  policyNo!: string;
  estimatedLoss!: number;
  dateOfAccident!: Date;
  claimStatus!: boolean;
  amtApprovedBySurveyor!: number;
  insuranceCompanyApproval!: boolean;
  withdrawClaim!: boolean;
  surveyorFees!: number;
  claimId!: string;
}