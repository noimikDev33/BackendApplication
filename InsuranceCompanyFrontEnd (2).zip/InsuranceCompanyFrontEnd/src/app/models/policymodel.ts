export class Policy {
    insuredFirstName !: string;
    insuredLastName !: string;
    dateOfInsurance !: Date;
    email !: string;
    vehicleNo !: number;
    status !: boolean;
    policyId !:string
}

