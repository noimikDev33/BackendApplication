import { NgModule } from '@angular/core';
import { RouterModule, Routes, provideRouter } from '@angular/router';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';

import { AboutComponent } from './components/GetAllClaims/about.component';
import { ServicesComponent } from './components/Update Claims/services.component';

import { AddNewClaimsComponent } from './components/add-new-claims/add-new-claims.component';
import { GetMonthlyClaimsDataComponent } from './components/get-monthly-claims-data/get-monthly-claims-data.component';

const routes: Routes = [
  {
    path: '', component: AdminDashboardComponent,
    children: [
      { path: 'add-new-claims', component: AddNewClaimsComponent },
      { path: 'get-monthly-claims-data', component: GetMonthlyClaimsDataComponent },

      { path: 'about', component: AboutComponent },
      { path: 'services', component: ServicesComponent },

      { path: 'services/:id', component: ServicesComponent },
      { path: '', redirectTo: '/admin/home', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],

})
export class AdminRoutingModule { }
