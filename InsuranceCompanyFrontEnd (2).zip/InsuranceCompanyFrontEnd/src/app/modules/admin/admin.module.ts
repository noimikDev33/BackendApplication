import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { AboutComponent } from './components/GetAllClaims/about.component';

import { ServicesComponent } from './components/Update Claims/services.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddNewClaimsComponent } from './components/add-new-claims/add-new-claims.component';
import { GetMonthlyClaimsDataComponent } from './components/get-monthly-claims-data/get-monthly-claims-data.component';
import { AlertComponent } from 'src/app/components/alert/alert.component';
import { AppModule } from 'src/app/app.module';


@NgModule({
  declarations: [
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    AddNewClaimsComponent,
    AboutComponent,
    ServicesComponent,
    AddNewClaimsComponent,
    GetMonthlyClaimsDataComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    FormsModule,

  ]
})
export class AdminModule { }
