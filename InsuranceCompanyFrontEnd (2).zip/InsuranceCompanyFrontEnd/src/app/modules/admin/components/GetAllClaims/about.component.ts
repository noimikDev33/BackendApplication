import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimDetails } from 'src/app/models/claimdetailsmodel';
import { AdminDataService } from 'src/app/services/admin/admin-data.service';



AdminDataService
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {


  claimList: ClaimDetails[];
  claim: ClaimDetails = {
    claimId: "",
    policyNo: "",
    estimatedLoss: 0,
    dateOfAccident: new Date,
    claimStatus: true,
    amtApprovedBySurveyor: 0,
    insuranceCompanyApproval: true,
    withdrawClaim: true,
    surveyorFees: 0,
  }
  viewDataLabel: string;
  noDataFound: string;

  isLoaded: boolean = false;


  constructor(private adminDataService: AdminDataService, private router: Router) {
    this.viewDataLabel = "Press View All To View All data ";

  }

  ngOnInit(): void {

  }
  onclick() {
    this.isLoaded = false;

    this.adminDataService.getAllClaims().subscribe({
      next: (data) => {
        this.isLoaded = true
        this.claimList = data
      },
      error: error => {
        this.noDataFound = error.error.message
        this.isLoaded = true
      }
    });



  }


  OnEditFunction(id: string) {

    this.router.navigate(['/admin/services', id]);
  }


}
