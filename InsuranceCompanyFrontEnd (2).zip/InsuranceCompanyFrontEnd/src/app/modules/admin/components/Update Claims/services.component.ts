import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClaimDetails } from 'src/app/models/claimdetailsmodel';
import { AdminDataService } from 'src/app/services/admin/admin-data.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  public showMyMessage = false;
  errMessage: string = ''

  claim = new ClaimDetails()
  constructor(private adminDataService: AdminDataService, private router: Router, private activatedRoute: ActivatedRoute) { }



  ngOnInit(): void {

    this.claim.claimId = this.activatedRoute.snapshot.paramMap.get('id')!;

  }


  onIdSearch() {

    this.adminDataService.getClaimDetailsById(this.claim.claimId).subscribe(data => this.claim = data,
      error => this.errMessage = error.error.message);


  }


  onUpdate() {

    this.adminDataService.updateClaimDetailsById(this.claim.claimId, this.claim).subscribe(data => console.log(data), error => console.log(error))
    this.showMyMessage = true
    this.claim = new ClaimDetails()
    setTimeout(() => {
      this.router.navigate(['/admin/about'])
    }, 2000)

  }

}
