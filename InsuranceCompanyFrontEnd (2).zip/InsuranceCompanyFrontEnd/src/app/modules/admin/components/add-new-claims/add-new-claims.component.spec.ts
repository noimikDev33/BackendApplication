import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewClaimsComponent } from './add-new-claims.component';

describe('AddNewClaimsComponent', () => {
  let component: AddNewClaimsComponent;
  let fixture: ComponentFixture<AddNewClaimsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddNewClaimsComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(AddNewClaimsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
