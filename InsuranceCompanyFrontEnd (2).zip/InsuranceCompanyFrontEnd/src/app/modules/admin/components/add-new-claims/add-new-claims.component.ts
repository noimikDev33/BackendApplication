import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimDetails } from 'src/app/models/claimdetailsmodel';
import { AdminDataService } from 'src/app/services/admin/admin-data.service';
import { PolicyDataService } from 'src/app/services/policy/policy-data.service';

@Component({
  selector: 'app-add-new-claims',
  templateUrl: './add-new-claims.component.html',
  styleUrls: ['./add-new-claims.component.css']
})
export class AddNewClaimsComponent implements OnInit {


  myArray: any[] = new Array();
  constructor(private router: Router, private adminDataService: AdminDataService, private policyDataService: PolicyDataService) { }
  showMyMessage = false;
  ngOnInit(): void {
  }

  claim = new ClaimDetails()


  // onDropDown() {
  //   console.log("Hello");
  // }





  getPolicyId() {
    this.policyDataService.getAllPolicyId().
      subscribe(data => this.myArray = data, error => console.log(error));
    console.log(this.myArray);
  }

  onClick() {
    console.log(this.claim);
    this.adminDataService.addNewClaims(this.claim)
      .subscribe(data => {
        console.log(data)

      }
        , error => console.log(error));
    this.claim = new ClaimDetails()
    this.showMyMessage = true
    setTimeout(() => {
      this.router.navigate(['/admin/about'])
    }, 2000)
  }
}
