import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMonthlyClaimsDataComponent } from './get-monthly-claims-data.component';

describe('GetMonthlyClaimsDataComponent', () => {
  let component: GetMonthlyClaimsDataComponent;
  let fixture: ComponentFixture<GetMonthlyClaimsDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GetMonthlyClaimsDataComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(GetMonthlyClaimsDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
