import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClaimDetails } from 'src/app/models/claimdetailsmodel';
import { AdminDataService } from 'src/app/services/admin/admin-data.service';

@Component({
  selector: 'app-get-monthly-claims-data',
  templateUrl: './get-monthly-claims-data.component.html',
  styleUrls: ['./get-monthly-claims-data.component.css']
})
export class GetMonthlyClaimsDataComponent implements OnInit {

  noDataFound: string;
  claimList: ClaimDetails[] = [];
  claims = new ClaimDetails();
  constructor(private adminDataService: AdminDataService, private activatedRoute: ActivatedRoute, private router: Router) {

    this.noDataFound = "No Data Found";
  }

  ngOnInit(): void {
    this.claims.claimId = this.activatedRoute.snapshot.paramMap.get('id')!;

  }

  onSearchOf() {
    const dateOfAccident = new Date(this.claims.dateOfAccident);
    const month = dateOfAccident.getMonth() + 1;
    const year = dateOfAccident.getFullYear();

    this.adminDataService.getClaimsDetailsMonthlyWise(month, year).subscribe
      (data => this.claimList = data, error => console.log(error))
  }
  OnEditFunction(id: string) {
    // Assuming you have the 'id' value (e.g., from your claim or policy)
    // Redirect to the 'Editor' page with the 'id' parameter
    this.router.navigate(['/admin/services', id]);
  }

}
