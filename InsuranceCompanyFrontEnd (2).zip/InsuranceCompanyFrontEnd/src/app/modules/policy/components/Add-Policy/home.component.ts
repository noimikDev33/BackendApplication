



















import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Policy } from 'src/app/models/policymodel';
import { AlertService } from 'src/app/services/alert/alert.service';
import { PolicyDataService } from 'src/app/services/policy/policy-data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  showMyMessage = false;
  acknow = false
  policyForm = this.fb.group({
    insuredFirstName: ['', [Validators.required, validateCustFirstNameLength()]],
    insuredLastName: ['', [Validators.required, validateCustLastNameLength()]],
    dateOfInsurance: ['', [Validators.required, validateBirthDate()]],
    email: ['', [Validators.required, validateEmail()]],
    vehicleNo: [''],
    status: [''],

  });

  constructor(private fb: FormBuilder, private router: Router, private policyDataService: PolicyDataService, private alertService: AlertService) { }
  ngOnInit(): void { }










  submitForm() {


    if (this.policyForm.valid) {


      this.policyDataService.addNewPolicy(this.policyForm.value)
        .subscribe({
          next: data => {



            this.alertService.showAlert.emit({
              alert: true,
              type: "success",
              message: "Policy Successfully Added"
            })
            // setTimeout(() => {
            //   window.location.reload()
            // }, 3000);
            // this.policyForm.reset();

            // this.policyForm.setValue({ insuredFirstName: '', insuredLastName: '', dateOfInsurance: '', status: 'false', email: '', vehicleNo: '', })



            var insuredLastName = <HTMLInputElement>(document.getElementById("insuredLastName"));
            insuredLastName.value = "";

            var insuredFirstName = <HTMLInputElement>(document.getElementById("insuredFirstName"));
            insuredFirstName.value = "";
            var dateOfInsurance = <HTMLInputElement>(document.getElementById("dateOfInsurance"));
            dateOfInsurance.value = "";
            var email = <HTMLInputElement>(document.getElementById("email"));
            email.value = "";
            var vehicleNo = <HTMLInputElement>(document.getElementById("vehicleNo"));
            vehicleNo.value = "";
            var status = <HTMLInputElement>(document.getElementById("status"));
            status.value = "false";




          },
          error: error => console.log(error)
        });


    } else {
      alert("Data is Invalid")
    }
  }



}


function validateCustFirstNameLength(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const insuredFirstName = control.value;
    const minLength = 3;


    if (insuredFirstName.length <= minLength) {
      return { invalidLength: true };
    }
    return null;

  };

}
function validateCustLastNameLength(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const insuredLastName = control.value;
    const minLength = 3;


    if (insuredLastName.length < minLength) {
      return { incorrectLength: true };
    }
    return null;

  };

}
export function validateEmail(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const email = control.value;
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailRegex.test(email)) {

      return { invalidEmailFormat: true };
    }

    if (!email.endsWith('@cognizant.com')) {

      return { invalidDomain: true };
    }

    return null; // Valid email
  };
}
export function validateBirthDate(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const dateOfInsurance = new Date(control.value);
    const currentDate = new Date();

    // Check if the date is between 2020 and the current year
    if (dateOfInsurance.getFullYear() < 2020 || dateOfInsurance > currentDate) {
      return { invalidAge: true };
    }

    return null;
  };
}

