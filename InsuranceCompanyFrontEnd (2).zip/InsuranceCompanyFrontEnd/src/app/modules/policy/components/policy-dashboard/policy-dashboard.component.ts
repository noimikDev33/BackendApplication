import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-dashboard',
  templateUrl: './policy-dashboard.component.html',
  styleUrls: ['./policy-dashboard.component.css']
})
export class PolicyDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
