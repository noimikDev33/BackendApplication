import { Component, OnInit } from '@angular/core';
import { Policy } from 'src/app/models/policymodel';
import { PolicyDataService } from 'src/app/services/policy/policy-data.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {


  viewDataLabel: string;
  noDataFound: String;

  policyList: Policy[] = []
  policy = new Policy

  constructor(private policyDataService: PolicyDataService) {
    this.viewDataLabel = "get All Data"
    this.noDataFound = "No Data Found"
  }

  ngOnInit(): void {
  }

  onViewAll() {

    this.policyDataService.getAllPolicies()
      .subscribe(data => this.policyList = data, error => console.log(error));
    this.policy = new Policy();
  }
}


