import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PolicyDashboardComponent } from './components/policy-dashboard/policy-dashboard.component';
import { HomeComponent } from './components/Add-Policy/home.component';
import { ViewComponent } from './components/view/view.component';

const routes: Routes = [
  {
    path:'',  component:PolicyDashboardComponent,
    children:[
      {path:'home',component:HomeComponent},
      {path:'view',component:ViewComponent},
      {path:'',redirectTo:'/policy/home',pathMatch:'full'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PolicyRoutingModule { }
