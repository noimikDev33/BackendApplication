import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PolicyRoutingModule } from './policy-routing.module';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { PolicyDashboardComponent } from './components/policy-dashboard/policy-dashboard.component';
import { HomeComponent } from './components/Add-Policy/home.component';
import { ViewComponent } from './components/view/view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertComponent } from 'src/app/components/alert/alert.component';
import { AlertService } from 'src/app/services/alert/alert.service';
import { AppModule } from 'src/app/app.module';


@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    PolicyDashboardComponent,
    HomeComponent,
    ViewComponent,
    AlertComponent
  ],
  imports: [
    CommonModule,
    PolicyRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    // AppModule
  ],
  providers: [AlertService]
})
export class PolicyModule { }
