import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ClaimDetails } from 'src/app/models/claimdetailsmodel';

HttpClient

@Injectable({
  providedIn: 'root'
})
export class AdminDataService {

  baseUrl1 = `http://localhost:8082/api/claims/new`



  constructor(private HttpClient: HttpClient) { }


  public addNewClaims(ClaimDetails: any) {

    return this.HttpClient.post<ClaimDetails>(this.baseUrl1, ClaimDetails);

  }

  public getAllClaims(): Observable<ClaimDetails[]> {


    return this.HttpClient.get<ClaimDetails[]>(`http://localhost:8082/getAllClaimDetails`)

  }




  public getClaimDetailsById(id: any,) {
    console.log("service here")
    return this.HttpClient.get<ClaimDetails>(`http://localhost:8082/getClaimDetailsById/${id}`)
  }


  public updateClaimDetailsById(id: any, ClaimDetails: any) {

    return this.HttpClient.put<ClaimDetails>(`http://localhost:8082/api/claims/update/${id}`, ClaimDetails)
  }
  public getClaimsDetailsMonthlyWise(month: any, year: any): Observable<ClaimDetails[]> {

    return this.HttpClient.get<ClaimDetails[]>(`http://localhost:8082/api/claimStatus/report/${month}/${year}`)
  }


}

