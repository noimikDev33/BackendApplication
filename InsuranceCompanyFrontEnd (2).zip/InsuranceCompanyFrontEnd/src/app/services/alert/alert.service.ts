import { EventEmitter, Injectable } from "@angular/core";


@Injectable()
export class AlertService {

    showAlert = new EventEmitter<{
        alert: boolean,
        type: string,
        message: string
    }>();
}