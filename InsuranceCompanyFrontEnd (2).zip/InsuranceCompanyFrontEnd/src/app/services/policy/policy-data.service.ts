import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PolicyModule } from 'src/app/modules/policy/policy.module';
import { Policy } from 'src/app/models/policymodel';
import { Observable } from 'rxjs';


HttpClient

@Injectable({
  providedIn: 'root'
})
export class PolicyDataService {
  baseUrl = `http://localhost:8082/addPolicy`

  constructor(private HttpClient: HttpClient) { }


  public addNewPolicy(ClaimDetails: any) {

    return this.HttpClient.post<Policy>(this.baseUrl, ClaimDetails);

  }
  public getAllPolicies(): Observable<Policy[]> {


    return this.HttpClient.get<Policy[]>(`http://localhost:8082/getAllPolicy`)

  }


  public getAllPolicyId(): Observable<Policy[]> {


    return this.HttpClient.get<Policy[]>(`http://localhost:8082/getAllPolicyId`)

  }

}
