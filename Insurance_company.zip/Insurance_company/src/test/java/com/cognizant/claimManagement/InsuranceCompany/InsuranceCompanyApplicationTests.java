package com.cognizant.claimManagement.InsuranceCompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceCompanyApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
